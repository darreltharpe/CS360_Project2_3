package CS360.project2_3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginScreen extends AppCompatActivity {

    Button loginButton, signupButton;
    EditText usernameArea, passwordArea;
    DatabaseManager dbm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_screen);

        dbm = DatabaseManager.instanceOf(this);
        dbm.getReadableDatabase();
        dbm.close();

        usernameArea = findViewById(R.id.usernameArea);
        passwordArea = findViewById(R.id.passwordArea);


        //Access main inventory activity button
        loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginRun();
            }
        });

        signupButton = findViewById(R.id.signupButton);
        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signupRun();
            }
        });

    }

    // checks empty entries, searches for match, allows pass for success or alert toast
    private void loginRun() {
        boolean user = checkUsername();
        boolean pass = checkPassword();
        if (user == true && pass == true) {
            boolean log = dbm.SearchforLogin(usernameArea.getText().toString(), passwordArea.getText().toString());
            if (log == true) {
                passToInventory();
            } else {
                Toast.makeText(LoginScreen.this, "Invalid login", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Checks for empty entries, searches database for entries, adds if not found
    private void signupRun() {
        boolean user = checkUsername();
        boolean pass = checkPassword();
        if (user == true && pass == true) {
            boolean log = dbm.SearchforLogin(usernameArea.getText().toString(), passwordArea.getText().toString());
            if (log == false) {
                dbm.addUser(usernameArea.getText().toString(), passwordArea.getText().toString());
            } else {
                Toast.makeText(LoginScreen.this, "Login already exists", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //Access main inventory activity
    public void passToInventory() {
        Intent AccessInventoryIntent = new Intent(this, MainActivity.class);
        startActivity(AccessInventoryIntent);
    }

    // check empty username
    private boolean checkUsername() {
        if (usernameArea.getText().toString().trim().length() == 0) {
            Toast.makeText(this, "No username entered", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }
    }

    // check empty password
    private boolean checkPassword() {
        if (passwordArea.getText().toString().trim().length() == 0) {
            Toast.makeText(this, "No password entered", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }
    }


}
