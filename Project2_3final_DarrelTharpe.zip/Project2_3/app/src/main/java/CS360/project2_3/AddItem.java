package CS360.project2_3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class AddItem extends Activity {
//Activity is implemented as a dialog via manifest theme setting

    Button addButton, cancelButton;
    EditText newItemName, newItemAmount;
    DatabaseManager dbm;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_item);

        dbm = DatabaseManager.instanceOf(this);

        newItemName = findViewById(R.id.newItemName);
        newItemAmount = findViewById(R.id.newItemAmount);

        addButton = findViewById(R.id.addNewButton);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addNewItem();
                returnToMain();
            }
        });

        // Halt add item button
        cancelButton = findViewById(R.id.cancelNewButton);
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                returnToMain();
            }
        });

    }


    // Pulls info from edittexts, checks input, converts amount to int type, calls DatabaseManager addItem, confirms result
    private void addNewItem() {
        String name = newItemName.getText().toString();
        String amount = newItemAmount.getText().toString();

        if(name.isEmpty()) {
            Toast.makeText(AddItem.this, "Must enter an item name", Toast.LENGTH_SHORT).show();
            return;
        }
        if(amount.isEmpty()) {
            amount = "0";
        }
        int intamount = Integer.parseInt(amount);

        boolean result = dbm.addItem(name, intamount);

        if(result == true){
            Toast.makeText(AddItem.this, "Added Successfully!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(AddItem.this, "Something went wrong...", Toast.LENGTH_SHORT).show();
        }
    }


    //Return to Main Activity
    private void returnToMain() {
        Intent ReturnToInventoryIntent = new Intent(this, MainActivity.class);
        startActivity(ReturnToInventoryIntent);
    }
}
