package CS360.project2_3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DatabaseManager extends SQLiteOpenHelper {

    private static DatabaseManager databaseManager;

    private static final String TAG = "DatabaseManager";

    private static final String DATABASE_NAME = "Inventory_Database.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE1_NAME = "Accounts";
    private static final String USERNAME_FIELD = "Username";
    private static final String PASSWORD_FIELD = "Password";
    private static final String ID_ACC = "IdAcc";


    private static final String TABLE2_NAME = "Inventory";
    private static final String ITEM_NAME_FIELD = "Item_Name";
    private static final String ITEM_COUNT_FIELD = "Item_Count";
    private static final String ID_INV = "IdInv";

    public DatabaseManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public static DatabaseManager instanceOf(Context context) {
        if(databaseManager == null) {
            databaseManager = new DatabaseManager(context);
        }
        return databaseManager;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        StringBuilder tbl1;
        tbl1 = new StringBuilder()
                .append("CREATE TABLE ")
                .append(TABLE1_NAME)
                .append("(")
                .append(ID_ACC)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(USERNAME_FIELD)
                .append(" TEXT, ")
                .append(PASSWORD_FIELD)
                .append(" TEXT)");
        db.execSQL(tbl1.toString());

        StringBuilder tbl2;
        tbl2 = new StringBuilder()
                .append("CREATE TABLE ")
                .append(TABLE2_NAME)
                .append("(")
                .append(ID_INV)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(ITEM_NAME_FIELD)
                .append(" TEXT, ")
                .append(ITEM_COUNT_FIELD)
                .append(" INT)");
        db.execSQL(tbl2.toString());
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Not implemented
    }

    // Passes addItem edittext values to insert, confirms and logs result
    public boolean addItem(String itemName, int itemCount){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(ITEM_NAME_FIELD, itemName);
        values.put(ITEM_COUNT_FIELD, itemCount);

        long result = db.insert(TABLE2_NAME, null, values);
        db.close();

        if(result == -1) {
            Log.d(TAG,"addItem: failed");
            return false;
        } else {
            Log.d(TAG,"addItem: added "+itemName+" and "+itemCount);
            return true;
        }
    }

    // Passes login edittexts to insert
    public void addUser(String userName, String userPass){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(USERNAME_FIELD, userName);
        values.put(PASSWORD_FIELD, userPass);

        db.insert(TABLE1_NAME, null, values);
        db.close();
    }


    // Reads id column from table 2 into temporary list
    public List<String> getIds() {
        List<String> temp = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT "+ID_INV+" FROM "+TABLE2_NAME, null);

        while(c.moveToNext()) {
            temp.add(String.valueOf(c.getLong(0)));
        }
        c.close();
        db.close();

        return temp;
    }

    public List<String> getNames() {
        List<String> temp = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT "+ITEM_NAME_FIELD+" FROM "+TABLE2_NAME, null);

        while(c.moveToNext()) {
            temp.add(c.getString(0)); //add the item
        }
        c.close();
        db.close();

        return temp;
    }

    public List<String> getAmounts() {
        List<String> temp = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT "+ITEM_COUNT_FIELD+" FROM "+TABLE2_NAME, null);

        while(c.moveToNext()) {
            temp.add(String.valueOf(c.getInt(0)));
        }
        c.close();
        db.close();

        return temp;
    }

    public void addToCount(String invID) {
        int invNum = Integer.parseInt(invID);
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("UPDATE "+TABLE2_NAME+" SET "+ITEM_COUNT_FIELD+" = "+ITEM_COUNT_FIELD+" +1 WHERE "+ID_INV+" = "+invNum);
        db.close();
    }

    public void subFromCount(String invID) {
        int invNum = Integer.parseInt(invID);
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("UPDATE "+TABLE2_NAME+" SET "+ITEM_COUNT_FIELD+" = "+ITEM_COUNT_FIELD+" -1 WHERE "+ID_INV+" = "+invNum);
        db.close();
    }

    public void deleteItemEntry(String invID) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM "+TABLE2_NAME+" WHERE "+ID_INV+" = "+invID);
        db.close();
    }

    public boolean SearchforLogin(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM "+TABLE1_NAME+" WHERE "+USERNAME_FIELD+" = ? AND "+PASSWORD_FIELD+" = ?", new String[] {username, password});

        if (c.getCount() > 0) {
            return true;
        } else {
            return false;
        }
    }

}
