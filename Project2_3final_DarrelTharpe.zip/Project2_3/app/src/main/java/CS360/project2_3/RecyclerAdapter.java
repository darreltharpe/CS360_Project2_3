package CS360.project2_3;

import static android.Manifest.permission.READ_PHONE_NUMBERS;
import static android.Manifest.permission.SEND_SMS;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.telephony.SubscriptionManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {
    //Currently only implements Item Name, still needs implementation of
    // Item Count and add, subtract and remove buttons

    List<String> invID, invNames, invAmt;
    LayoutInflater inflater;
    DatabaseManager dbm;
    Context ctx;
    String Phonenumber;
    SmsManager smsman;
    SubscriptionManager sm;
    boolean permissionGranted;

    public RecyclerAdapter(Context ctx, List<String> invID, List<String> invNames, List<String> invAmt, DatabaseManager dbm) {
        this.invID = invID;
        this.invNames = invNames;
        this.invAmt = invAmt;
        this.inflater = LayoutInflater.from(ctx);
        this.dbm = dbm;
        this.ctx = ctx;
        smsman = ctx.getSystemService(SmsManager.class);
        sm = (SubscriptionManager) ctx.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.inventory_item, parent, false);
        checkSMSPermissionRecAd();
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.itemID.setText(invID.get(position))
        ;
        holder.itemName.setText(invNames.get(position));
        holder.itemCount.setText(invAmt.get(position));
        holder.addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbm.addToCount(holder.itemID.getText().toString());
                MainActivity.populateInvAmt();
                notifyItemChanged(holder.getAdapterPosition());
            }
        });

        // Subtracts from database count and repopulates invamt, does not subtract below zero
        // calls sendSMS only if permission granted
        holder.subButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Integer.parseInt(holder.itemCount.getText().toString()) >= 1) {
                    dbm.subFromCount(holder.itemID.getText().toString());
                    MainActivity.populateInvAmt();
                    notifyItemChanged(holder.getAdapterPosition());
                }
                if (Integer.parseInt(holder.itemCount.getText().toString()) == 1) {
                    if (permissionGranted == true) {
                        sendSMS(holder.itemName.getText().toString());
                    }
                }
            }
        });

        // deletes entry form database then repopulates list.
        holder.removeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbm.deleteItemEntry(holder.itemID.getText().toString());
                MainActivity.populateInvId();
                MainActivity.populateInvName();
                MainActivity.populateInvAmt();
                notifyItemChanged(holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        if (invNames != null) {
            return invNames.size();
        }
        return 0;
    }

    //--------------------------SMS functionality--------------------------------

    // Checks permission and sets variables for SMS use
    public void checkSMSPermissionRecAd() {
        if(ContextCompat.checkSelfPermission(ctx, SEND_SMS) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(ctx, READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED) {
            permissionGranted = true;
            getPhoneNumber();
        }
    }

    // Gets phone number. Permission checked in checkSMSPermissionRecAd, so automated
    // permission check suggestion suppressed
    @SuppressLint("MissingPermission")
    private void getPhoneNumber() {
        Phonenumber = sm.getPhoneNumber(sm.getDefaultSmsSubscriptionId()).toString();
    }

    // Sends out of stock message
    public void sendSMS(String item) {
        smsman.sendTextMessage(Phonenumber, null, item+" is out of stock!", null, null);
    }







    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemID, itemName, itemCount;
        Button addButton, subButton, removeButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemID = itemView.findViewById(R.id.dbIdNum);
            itemName = itemView.findViewById(R.id.itemName);
            itemCount = itemView.findViewById(R.id.itemCount);
            addButton = itemView.findViewById(R.id.addButton);
            subButton = itemView.findViewById(R.id.subButton);
            removeButton = itemView.findViewById(R.id.removeButton);
        }
    }



}
