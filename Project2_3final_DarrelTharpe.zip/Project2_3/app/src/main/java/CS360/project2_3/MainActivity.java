package CS360.project2_3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView InventoryScroll;
    static List<String> invID, invName, invAmt;
    static RecyclerAdapter adapter;
    Button backButton, checkSMSButton;
    FloatingActionButton newItemFAB;
    static DatabaseManager dbm;
    private static String DATABASE_FILE_PATH = "/data/data/CS360.project2_3/databases/Inventory_Database.db";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        InventoryScroll = findViewById(R.id.InventoryScroll);

        dbm = DatabaseManager.instanceOf(this);

        //Database columns as lists
        invID = new ArrayList<>();
        populateInvId();

        invName = new ArrayList<>();
        populateInvName();

        invAmt = new ArrayList<>();
        populateInvAmt();

        //RecyclerView Setup
        adapter = new RecyclerAdapter(this, invID, invName, invAmt, dbm);
        GridLayoutManager gridManager= new GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false);
        InventoryScroll.setLayoutManager(gridManager);
        InventoryScroll.setAdapter(adapter);

        //Return to Login button
        backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logOut();
            }
        });

        //Open Add Item screen Floating Action Button
        newItemFAB = findViewById(R.id.newItemFAB);
        newItemFAB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAddItemDialogue();
            }
        });

        //Go to SMS screen button
        checkSMSButton = findViewById(R.id.checkSMSButton);
        checkSMSButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSMSChecker();
            }
        });

    }

    //Return to Login activity
    private void logOut() {
        Intent LogoutIntent = new Intent(this, LoginScreen.class);
        startActivity(LogoutIntent);
    }

    //Open Add Item dialog activity
    private void openAddItemDialogue() {
        Intent AddItemIntent = new Intent(this, AddItem.class);
        startActivity(AddItemIntent);
    }

    //Move to SMS setup screen
    private void openSMSChecker() {
        Intent CheckNotificationsIntent = new Intent(this, NotificationsUI.class);
        startActivity(CheckNotificationsIntent);
    }

    public static void populateInvId() {
        List temp = dbm.getIds();
        invID.clear();
        invID.addAll(temp);
    }

    public static void populateInvName() {
        List temp = dbm.getNames();
        invName.clear();
        invName.addAll(temp);
    }

    public static void populateInvAmt() {
        List temp = dbm.getAmounts();
        invAmt.clear();
        invAmt.addAll(temp);
    }

}
