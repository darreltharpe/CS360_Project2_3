package CS360.project2_3;

import static android.Manifest.permission.READ_PHONE_NUMBERS;
import static android.Manifest.permission.SEND_SMS;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SubscriptionManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class NotificationsUI extends AppCompatActivity {

    Button backToMainButton, checkSMSButton;
    TextView permissionStatus;
    private static String Phonenumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notifications_ui);

        permissionStatus = findViewById(R.id.permissionStatus);

        backToMainButton = findViewById(R.id.backToMainButton);
        backToMainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goBackToMain();
            }
        });

        checkSMSButton = findViewById(R.id.checkSMSButton);
        checkSMSButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                notificationButtonClick();
            }
        });
    }

    private void notificationButtonClick() {
        boolean value = checkSMSPermissionNoteUI();
        if(value == true) {
            permissionStatus.setText("Notifications activated!");
        } else {
            requestPermission();
        }
    }

    public boolean checkSMSPermissionNoteUI() {
        if(ContextCompat.checkSelfPermission(this, SEND_SMS) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            return false;
        }
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(NotificationsUI.this,
                new String[]{SEND_SMS, READ_PHONE_NUMBERS}, 999);
    }

    private void goBackToMain() {
        Intent GoBackIntent = new Intent(this, MainActivity.class);
        startActivity(GoBackIntent);
    }


}
